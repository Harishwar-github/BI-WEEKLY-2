import threading

result = [False]*4

#edge cases
def sudokuCheck1(grid):
	if not grid:
		result[0] = False
	result[0] = True
    
#rows by rows checking 
def sudokuCheck2(grid):
	hset = set()
	for i in range(9):
		for j in range(9):
			if grid[i][j] in hset:
				result[1] = False
				return
			else:
				hset.add(grid[i][j])
		hset = set()
	result[1] = True

#cols by cols checking
def sudokuCheck3(grid):        
	hset = set()
	for i in range(9):
		for j in range(9):
			if grid[j][i] in hset:
				result[2] = False
				return
			else:
				hset.add(grid[j][i])
		hset = set()
	result[2] = True

def sudokuCheck4(grid):
	subs = [range(0,3), range(3,6), range(6,9)]
	subgrids = [] 
	for x in subs:
		for y in subs:
			subgrids.append([x,y])
	for (row_range, column_range) in subgrids:
		hset = set()
		for i in row_range:
			for j in column_range:              
				if grid[i][j] in hset:
					result[3] = False
					return
				else:
					hset.add(grid[i][j])

	result[3] = True

if __name__ == "__main__":
	grid = [
		[8, 3, 5, 4, 1, 6, 9, 2, 7],
		[2, 9, 6, 8, 5, 7, 4, 3, 1],
		[4, 1, 7, 2, 9, 3, 6, 5, 8],
		[5, 6, 9, 1, 3, 4, 7, 8, 2],
		[1, 2, 3, 6, 7, 8, 5, 4, 9],
		[7, 4, 8, 5, 2, 9, 1, 6, 3],
		[6, 5, 2, 7, 8, 1, 3, 9, 4],
		[9, 8, 1, 3, 4, 5, 2, 7, 6],
		[3, 7, 4, 9, 6, 2, 8, 1, 5]
	]

	t1 = threading.Thread(target=sudokuCheck1, args=(grid,))
	t2 = threading.Thread(target=sudokuCheck2, args=(grid,))
	t3 = threading.Thread(target=sudokuCheck3, args=(grid,))
	t4 = threading.Thread(target=sudokuCheck4, args=(grid,))
	
	t1.start()
	t2.start()
	t3.start()
	t4.start()

	t1.join()
	t2.join()
	t3.join()
	t4.join()

	checked = True
	for temp in result:
		if temp == False:
			print("Sudoku is incorrect")
			checked = False
	if checked:
		print("Sudoku is correct")